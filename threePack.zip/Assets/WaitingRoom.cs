﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Networking;

public class WaitingRoom : NetworkBehaviour {
  private void Start() {
    if (isLocalPlayer) {
      
    }
  }
}
